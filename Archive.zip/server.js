const express = require('express')
const bodyParser = require('body-parser')

//for api
const axios = require('axios').default;
const params = {
    access_key: '1d4816a457fb3b9b32b2cc6091653014',
    query: 'New York'
}
//

const app = express()
app.use(bodyParser.urlencoded({ extended: true }))

const port = 3001

app.get('/', (req, res) => {
    res.sendFile(__dirname+'/index.html')
})
app.get('/calc',(req, res) =>{
    res.sendFile(__dirname+"/calc.html")
})
app.post('/calc',(req,res)=>{
    let num1 = Number(req.body.num1)
    let num2 = Number(req.body.num2)
    let result = num1 + num2
    res.send("Result: " + result)
})


app.get('/APITest', (req,res) => {
    res.sendFile(__dirname+'/APITest.html')
})
app.post('/apireq', (req,res) => {
    let name = req.body.apiin
    console.log(params.access_key, name)
    axios.get('https://api.weatherstack.com/current', {access_key: params.access_key, query: name})
        .then(response => {
            const apiResponse = response.data;
            console.log(apiResponse)
            res.send(`Current temperature in ${apiResponse.location.name} is ${apiResponse.current.temperature}℃`);
        }).catch(error => {
        res.send(error);
    });
})


//
//
// https://api.weatherstack.com/current
//         ? access_key = YOUR_ACCESS_KEY
//     & query = New York

app.listen(port, () => {
    console.log(`The app listening on port ${port}`)
})